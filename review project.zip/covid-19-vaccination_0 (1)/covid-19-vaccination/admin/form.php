<form role="form" class="form-horizontal" method= "POST" action="">
							<div class="form-group">
								<div class="col-sm-12">
 <select name="cmdstatus" id="select" class="form-control" required="">
    <option value = "">Select</option>
    <option value = "Not Available">Not Available</option>
    <option value = "Negative">Negative</option>
    <option value = "Positive">Positive</option>

      </select> 
												</div>
							</div>
							
							<div class="row">
								<div class="col-sm-10">
									<button type="submit" name="btnsubmit" class="btn btn-light btn-radius btn-brd grd1">Update</button>
								</div>
							</div>
						</form>